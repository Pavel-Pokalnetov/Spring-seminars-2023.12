package com.example.example4sem6_rikky_and_morty_rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Example4sem6RikkyAndMortyRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
