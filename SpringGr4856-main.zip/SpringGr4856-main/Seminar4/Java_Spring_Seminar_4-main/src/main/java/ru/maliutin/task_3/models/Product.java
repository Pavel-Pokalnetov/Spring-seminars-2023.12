package ru.maliutin.task_3.models;

import lombok.Data;

@Data
public class Product {

    private String name;

    private double price;

}
