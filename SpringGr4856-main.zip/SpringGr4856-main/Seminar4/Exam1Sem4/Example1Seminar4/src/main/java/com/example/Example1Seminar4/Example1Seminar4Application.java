package com.example.Example1Seminar4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Example1Seminar4Application {

	public static void main(String[] args) {
		SpringApplication.run(Example1Seminar4Application.class, args);
	}

}
