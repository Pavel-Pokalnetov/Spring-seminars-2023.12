package com.example.Example1Seminar4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Example1Seminar4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
