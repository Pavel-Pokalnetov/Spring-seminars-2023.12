package com.example.Example2Seminar4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Example2Seminar4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
