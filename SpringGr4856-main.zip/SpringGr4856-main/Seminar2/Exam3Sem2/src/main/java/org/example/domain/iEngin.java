package org.example.domain;

public interface iEngin {
    public  void startEngine();
}
