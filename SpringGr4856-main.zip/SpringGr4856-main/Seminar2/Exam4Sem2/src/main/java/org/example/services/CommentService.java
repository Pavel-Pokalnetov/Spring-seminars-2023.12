package org.example.services;

public class CommentService {
    public CommentService() {
        System.out.println("Создан CommentService!");
    }
}
