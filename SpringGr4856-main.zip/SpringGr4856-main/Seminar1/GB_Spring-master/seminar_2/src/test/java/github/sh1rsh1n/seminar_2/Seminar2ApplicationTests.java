package github.sh1rsh1n.seminar_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Seminar2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
