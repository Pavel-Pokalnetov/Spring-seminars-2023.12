package com.example.sem3example2REST;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sem3example2RestApplicationTests {

	@Test
	void contextLoads() {
	}

}
