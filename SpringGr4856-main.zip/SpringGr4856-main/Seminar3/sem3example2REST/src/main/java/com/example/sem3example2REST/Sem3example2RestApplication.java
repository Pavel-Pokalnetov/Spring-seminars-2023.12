package com.example.sem3example2REST;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sem3example2RestApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sem3example2RestApplication.class, args);
	}

}
