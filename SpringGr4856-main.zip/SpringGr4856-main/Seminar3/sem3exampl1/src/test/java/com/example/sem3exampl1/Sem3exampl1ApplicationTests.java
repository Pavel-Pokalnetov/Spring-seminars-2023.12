package com.example.sem3exampl1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sem3exampl1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
