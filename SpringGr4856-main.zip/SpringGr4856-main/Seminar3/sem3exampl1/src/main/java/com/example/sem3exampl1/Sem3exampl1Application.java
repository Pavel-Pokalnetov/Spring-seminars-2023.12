package com.example.sem3exampl1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sem3exampl1Application {

	public static void main(String[] args) {
		SpringApplication.run(Sem3exampl1Application.class, args);
	}

}
