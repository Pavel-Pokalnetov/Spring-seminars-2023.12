package com.example.example_2_seminar_5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Example2Seminar5ApplicationTests {

    @Test
    void contextLoads() {
    }

}
