package com.example.example_2_seminar_5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Example2Seminar5Application {

    public static void main(String[] args) {
        SpringApplication.run(Example2Seminar5Application.class, args);
    }

}
