insert into books (title, author, publication_year)
values ('Гарри Поттер', 'Дж. Роулинг', 2000);

insert into books (title, author, publication_year)
values ('Война и мир', 'Лев Толстой', 1950);
