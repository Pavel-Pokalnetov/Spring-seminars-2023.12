package com.example.spring_data_exam.exeption;

public class AccountNotFoundException extends RuntimeException {
}
