INSERT INTO account (name,amount) VALUES ('Jane Down', 1000);
INSERT INTO account (name,amount) VALUES ('John Read', 1000);