package com.example.sem5_springdata_ex2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sem5SpringdataEx2Application {

	public static void main(String[] args) {
		SpringApplication.run(Sem5SpringdataEx2Application.class, args);
	}

}
